import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
#import logging
from DBScanner import DBScanner
from Active_learning import Active_learning
from AdditionalFunction import AdditionalFunction
import time
import matplotlib.pyplot as plt

#logging.basicConfig(format="%(asctime)s [%(name)s] [%(levelname)s]: %(message)s", level=logging.INFO)
#logger = logging.getLogger(__name__)
#logger.info("program started")


def main():
    dataframe = pd.read_csv("News-sim3.csv")
    ad=AdditionalFunction()
    ml=ad.get_must_link(dataframe,0)
    cl=ad.get_connot_link(dataframe,0)


    stemmed=[' '.join(ad.stemming_tokenizer(x)) for x in dataframe.text]
    vectorizer = TfidfVectorizer(stop_words="english")
    # With stemmming
    #datavector = vectorizer.fit_transform(stemmed)
    #Without stemming
    datavector = vectorizer.fit_transform(list(dataframe.text))


    # db= DBScanner(datavector,dataframe)
    # db.dbscan(ml, cl)
    # db.printcluster()
    # db.getlabel()
    # f_measure=db.f_measure(dataframe)
    # db.evaluation(dataframe)
    # db.average_test(dataframe)
    # print("y1:", f_measure)
    consnum=0
    fmeasure=[]
    conslist=[]
    NMI=[]

    eps= 0.1
    min_pts = 0

    Outfile = open("output_News-sim3.txt", "w")

    for i in range(25):

        min_pts += 5
        consnum = 0
        if min_pts == 20:
            eps += 0.1
            min_pts = 0

        print("Run  %s,  Eps: %s, min_pts: % s \n" % (i, eps, min_pts))
        Outfile.write("Eps: %s, min_pts: % s \n" % (eps, min_pts))
        while consnum <= 600:
            db = DBScanner(datavector, dataframe, eps, min_pts)
            cluster_count = db.dbscan(ml, cl)
            print("Number of clusters found:", cluster_count)

            db.getlabel()
            #f_measure = db.f_measure(dataframe, ad)
            #db.evaluation(dataframe)
            print("constrain number:", consnum)
            #print("f-measure:", f_measure)
            #fmeasure.append(f_measure)
            nmi, fowlkes, hom, fscore, pairwise_score  = db.evaluation(dataframe)

            print("NMI result:", nmi)
            print("Fowlkes Mallows: ", fowlkes)
            print("Homogeneity, Completeness, vmeasure: ", str(hom))
            print("F1: ", fscore)
            print("Pairwise F1: ", pairwise_score)

            #NMI.append(nmi)
            #fmeasure.append(fscore)
            #conslist.append(consnum)

            Outfile.write("Number of clusters found: %s \n" % (cluster_count))
            Outfile.write("Number constraints: %s \n" % (consnum))
            Outfile.write("NMI: %s \n" % (nmi))
            Outfile.write("F measure: %s \n" % (fscore))
            Outfile.write("Pairwise F measure: %s \n" % (pairwise_score))
            Outfile.write("Fowlkes Mallows: %s \n" % (fowlkes))
            Outfile.write("Homogeneity, Completeness, vmeasure: %s \n" % (str(hom)))

            consnum+=50
            ml=ad.increase_ml(ml, 50)
            cl=ad.increase_cl(cl, 50)

        Outfile.write("---------------------------------- \n \n")

    Outfile.close()

    #print("result fmeasure:",fmeasure)
    # db2= DBScanner(datavector,dataframe)
    # db2.dbscan(ml2, cl2)
    # db2.printcluster()
    # db2.getlabel()
    # f_measure2=db2.f_measure(dataframe)
    # db2.evaluation(dataframe)
    # db2.average_test(dataframe)
    # print("y2:", f_measure2)

    #datetime = time.strftime("%Y%m%d-%H%M%S")
    # plt.plot(conslist, fmeasure, color='g',marker="o")
    # plt.plot(conslist, NMI, color='orange',marker="x")
    # plt.xlabel('Constraint num')
    # plt.ylabel('Evaluation')
    # plt.title('Result of Evaluation with increasing Constraints')
    # plt.savefig( datetime+"Evaluation.png")
    # plt.show()


    # al=Active_learning(datavector,train2)
    # al.active_selecting(ml,cl)


    #logger.info("finished")

if __name__ == '__main__':
    main()